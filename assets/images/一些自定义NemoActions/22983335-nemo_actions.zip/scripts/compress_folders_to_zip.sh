#!/bin/bash

# Check if zip is installed
if ! command -v zip >/dev/null 2>&1; then
    echo "Error: zip command not found. Please install zip (e.g., sudo apt install zip)."
    exit 1
fi

# Check if realpath is available (for absolute paths)
if ! command -v realpath >/dev/null 2>&1; then
    echo "Error: realpath command not found. Please install coreutils (usually pre-installed)."
    exit 1
fi

echo "Starting compression of selected folders..."

# Loop through all provided paths
for i in "$@"; do
    if [ -d "$i" ]; then
        # Get absolute path for safety
        abs_i=$(realpath "$i")
        # Extract folder name and parent directory
        folder_name=$(basename "$abs_i")
        parent_dir=$(dirname "$abs_i")
        
        # Check permissions
        if [ ! -r "$abs_i" ] || [ ! -w "$parent_dir" ]; then
            echo "Permission denied for $folder_name. Skipping."
            continue
        fi
        
        # Compress the folder quietly, create .zip in parent directory
        if zip -r -q "${parent_dir}/${folder_name}.zip" "$abs_i"; then
            echo "Successfully compressed: $folder_name to ${parent_dir}/${folder_name}.zip"
        else
            echo "Failed to compress: $folder_name"
        fi
    else
        echo "Skipping non-directory: $i"
    fi
done

echo "Compression process completed."
