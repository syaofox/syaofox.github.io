#!/usr/bin/env bash
# 一键备份 Seahorse + SSH + Git 凭证
# 保存为: ~/backup-seahorse-ssh.sh
# 用法: chmod +x backup-seahorse-ssh.sh && ./backup-seahorse-ssh.sh

set -e

BACKUP_DIR="/tmp/seahorse-ssh-backup-$(date +%Y%m%d-%H%M%S)"
FINAL_BACKUP="$HOME/seahorse-ssh-full-backup-$(date +%Y%m%d-%H%M%S).tar.gz"

echo "正在创建备份目录: $BACKUP_DIR"
mkdir -p "$BACKUP_DIR"/{keyrings,ssh}

# 1. 备份 Seahorse 密钥环（加密文件）
echo "正在备份 Seahorse 密钥环..."
cp -r ~/.local/share/keyrings/* "$BACKUP_DIR"/keyrings/ 2>/dev/null || true

# 2. 导出明文 PAT（可选防丢失）
echo "正在导出 GitHub PAT（明文）..."
secret-tool search --unlock server github.com > "$BACKUP_DIR"/github-pat.txt 2>/dev/null || echo "无 GitHub 凭证" > "$BACKUP_DIR"/github-pat.txt

# 3. 备份 SSH 私钥和配置
echo "正在备份 SSH 密钥..."
mkdir -p "$BACKUP_DIR"/ssh
cp ~/.ssh/id_* "$BACKUP_DIR"/ssh/ 2>/dev/null || true
cp ~/.ssh/config "$BACKUP_DIR"/ssh/ 2>/dev/null || true
cp ~/.ssh/known_hosts "$BACKUP_DIR"/ssh/ 2>/dev/null || true
cp ~/.ssh/authorized_keys "$BACKUP_DIR"/ssh/ 2>/dev/null || true

# 4. 导出 SSH 登录密码（如果记住过）
echo "正在导出 SSH 登录密码..."
secret-tool search --unlock protocol ssh >> "$BACKUP_DIR"/ssh-passwords.txt 2>/dev/null || true

# 5. 打包
echo "正在压缩备份..."
tar -czf "$FINAL_BACKUP" -C "$BACKUP_DIR" .

# 6. 清理
rm -rf "$BACKUP_DIR"

echo ""
echo "备份完成！"
echo "文件: $FINAL_BACKUP"
echo "请复制到 U 盘/云盘，并记住你的登录密码！"
echo "恢复时使用 restore-seahorse-ssh.sh"
