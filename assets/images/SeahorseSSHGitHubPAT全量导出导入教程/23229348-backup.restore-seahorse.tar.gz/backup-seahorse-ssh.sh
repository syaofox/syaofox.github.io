#!/usr/bin/env bash
# 一键备份 Seahorse + SSH + Git 凭证 → 输出到脚本所在目录
# 用法: 放在任意目录，运行 ./backup-seahorse-ssh.sh

set -e

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_DIR="$SCRIPT_DIR/backup-tmp-$(date +%Y%m%d-%H%M%S)"
FINAL_BACKUP="$SCRIPT_DIR/seahorse-ssh-full-backup-$(date +%Y%m%d-%H%M%S).tar.gz"

echo "正在创建临时备份目录: $BACKUP_DIR"
mkdir -p "$BACKUP_DIR"/{keyrings,ssh}

# 1. 备份 Seahorse 密钥环
echo "正在备份 Seahorse 密钥环..."
cp -r ~/.local/share/keyrings/* "$BACKUP_DIR"/keyrings/ 2>/dev/null || true

# 2. 导出 GitHub PAT（明文）
echo "正在导出 GitHub PAT..."
secret-tool search --unlock server github.com > "$BACKUP_DIR"/github-pat.txt 2>/dev/null || echo "无 GitHub 凭证" > "$BACKUP_DIR"/github-pat.txt

# 3. 备份 SSH 密钥和配置
echo "正在备份 SSH 密钥..."
mkdir -p "$BACKUP_DIR"/ssh
cp ~/.ssh/id_* "$BACKUP_DIR"/ssh/ 2>/dev/null || true
cp ~/.ssh/config "$BACKUP_DIR"/ssh/ 2>/dev/null || true
cp ~/.ssh/known_hosts "$BACKUP_DIR"/ssh/ 2>/dev/null || true
cp ~/.ssh/authorized_keys "$BACKUP_DIR"/ssh/ 2>/dev/null || true

# 4. 导出 SSH 登录密码
echo "正在导出 SSH 登录密码..."
secret-tool search --unlock protocol ssh >> "$BACKUP_DIR"/ssh-passwords.txt 2>/dev/null || true

# 5. 打包到脚本目录
echo "正在压缩到脚本目录..."
tar -czf "$FINAL_BACKUP" -C "$BACKUP_DIR" .

# 6. 清理
rm -rf "$BACKUP_DIR"

echo ""
echo "备份完成！"
echo "文件: $FINAL_BACKUP"
echo "位置: 脚本所在目录"
echo "请复制此文件到 U 盘/云盘，并记住你的登录密码！"
echo "恢复时将此文件与 restore-seahorse-ssh.sh 放在同一目录运行"