#!/usr/bin/env bash
# 一键恢复 Seahorse + SSH + Git 凭证 → 从脚本所在目录读取备份
# 用法: 将此脚本与 seahorse-ssh-full-backup-*.tar.gz 放在同一目录，运行 ./restore-seahorse-ssh.sh

set -e

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "脚本目录: $SCRIPT_DIR"

echo ""
echo "一键恢复 Seahorse + SSH + Git 凭证"
echo "请确保："
echo "  1. 用户名与旧系统相同"
echo "  2. 登录密码与旧系统相同"
echo "  3. 已安装: sudo apt install seahorse gnome-keyring libsecret-tools openssh-client git"
echo ""

# 查找当前目录下的最新备份
BACKUP_FILE=$(ls -t "$SCRIPT_DIR"/seahorse-ssh-full-backup-*.tar.gz 2>/dev/null | head -n1)
if [[ -z "$BACKUP_FILE" ]]; then
    echo "错误：在当前目录未找到备份文件！"
    echo "请将 seahorse-ssh-full-backup-*.tar.gz 与此脚本放在同一目录"
    exit 1
fi

echo "找到备份: $BACKUP_FILE"
echo "正在解压..."

# 临时解压目录
TEMP_DIR="/tmp/restore-seahorse-ssh"
rm -rf "$TEMP_DIR"
mkdir -p "$TEMP_DIR"
tar -xzf "$BACKUP_FILE" -C "$TEMP_DIR"

# 1. 恢复 keyrings
echo "正在恢复 Seahorse 密钥环..."
mkdir -p ~/.local/share/keyrings
cp "$TEMP_DIR"/keyrings/* ~/.local/share/keyrings/ 2>/dev/null || true
chmod 600 ~/.local/share/keyrings/*.keyring 2>/dev/null || true
chmod 700 ~/.local/share/keyrings/

# 2. 恢复 SSH
echo "正在恢复 SSH 密钥..."
mkdir -p ~/.ssh
cp "$TEMP_DIR"/ssh/id_* ~/.ssh/ 2>/dev/null || true
cp "$TEMP_DIR"/ssh/config ~/.ssh/ 2>/dev/null || true
cp "$TEMP_DIR"/ssh/known_hosts ~/.ssh/ 2>/dev/null || true
cp "$TEMP_DIR"/ssh/authorized_keys ~/.ssh/ 2>/dev/null || true
chmod 600 ~/.ssh/id_* 2>/dev/null || true
chmod 644 ~/.ssh/config ~/.ssh/known_hosts ~/.ssh/authorized_keys 2>/dev/null || true

# 3. 启动 GNOME Keyring
echo "正在启动 GNOME Keyring（含 ssh 组件）..."
eval $(gnome-keyring-daemon --start --components=pkcs11,secrets,ssh,gpg)
export SSH_AUTH_SOCK

# 4. 永久配置 .bashrc
echo "正在写入开机自启..."
if ! grep -q "gnome-keyring-daemon.*ssh" ~/.bashrc 2>/dev/null; then
    cat >> ~/.bashrc << 'EOF'

# === GNOME Keyring + SSH Agent (Auto Restore) ===
eval $(gnome-keyring-daemon --start --components=pkcs11,secrets,ssh,gpg)
export SSH_AUTH_SOCK
EOF
fi

# 5. 配置 Git
echo "正在配置 Git 使用 libsecret..."
git config --global credential.helper libsecret 2>/dev/null || true

# 6. 清理
rm -rf "$TEMP_DIR"

echo ""
echo "恢复完成！"
echo ""
echo "请执行以下操作触发解锁："
echo "   1. git ls-remote https://github.com/your-username/any-repo.git"
echo "      → 输入原登录密码解锁 keyring"
echo "   2. ssh your-server-ip"
echo "      → 自动登录"
echo "   3. seahorse &"
echo "      → 查看 Passwords → login → github.com"
echo ""
echo "重启终端或系统后，所有凭证自动生效！"