#!/bin/bash
# 保存到 ~/.local/share/nemo/scripts/ 或 /usr/share/nemo/scripts/

current_dir="$1"
timestamp=$(date +%Y%m%d%H%M%S)
output_file="$current_dir/clipboard-$timestamp.png"

xclip -selection clipboard -target image/png -o > "$output_file"

# 可选：显示成功通知
#if [ $? -eq 0 ]; then
#    notify-send "图片已保存" "保存为: $(basename "$output_file")"
#else
#    notify-send "错误" "剪贴板中没有图片数据或操作失败"
#fi
