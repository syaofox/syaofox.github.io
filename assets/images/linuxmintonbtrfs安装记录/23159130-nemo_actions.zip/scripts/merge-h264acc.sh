#!/bin/bash

# 检查 ffmpeg 和 ffprobe 是否安装
if ! command -v ffmpeg >/dev/null 2>&1 || ! command -v ffprobe >/dev/null 2>&1; then
    echo "错误: 未找到 ffmpeg 或 ffprobe 命令。请安装它们 (例如: sudo apt install ffmpeg)."
    read -p "按任意键退出..."
    exit 1
fi

# 检查是否提供了恰好两个文件
if [ $# -ne 2 ]; then
    echo "错误: 请提供恰好两个文件：第一个文件提供视频流，第二个文件提供音频流。"
    read -p "按任意键退出..."
    exit 1
fi

echo "正在开始处理和合并所选的媒体文件 (H.264/AAC转码)..."


# --- 函数：获取视频流编码器名称 ---
get_video_codec() {
    ffprobe -v error -select_streams v:0 -show_entries stream=codec_name -of default=noprint_wrappers=1:nokey=1 "$1" 2>/dev/null
}

# --- 函数：获取音频流编码器名称 ---
get_audio_codec() {
    ffprobe -v error -select_streams a:0 -show_entries stream=codec_name -of default=noprint_wrappers=1:nokey=1 "$1" 2>/dev/null
}


# --- 步骤 1: 设置源文件 ---

video_source="$1"
audio_source="$2"

echo "正在检查输入文件..."

# 检查第一个文件（视频源）
if [ ! -f "$video_source" ]; then
    echo "错误: 第一个文件不存在 - $video_source"
    read -p "按任意键退出..."
    exit 1
fi

# 检查第二个文件（音频源）
if [ ! -f "$audio_source" ]; then
    echo "错误: 第二个文件不存在 - $audio_source"
    read -p "按任意键退出..."
    exit 1
fi

echo "视频源文件: $video_source"
echo "音频源文件: $audio_source"

# --- 步骤 2: 检测编码格式并构建转码命令 ---

echo ""
echo "正在检测编码格式并准备转码..."

# 检测视频编码格式
video_codec_cmd=""
if [ -n "$video_source" ]; then
    video_codec=$(get_video_codec "$video_source" | tr '[:upper:]' '[:lower:]')
    echo "视频源编码格式: ${video_codec:-未知}"
    
    if [[ "$video_codec" == "h264" ]]; then
        video_codec_cmd="-c:v copy"
        echo "  -> H.264 视频流将直接复制"
    else
        video_codec_cmd="-c:v libx264 -crf 23 -preset medium"
        echo "  -> 非 H.264 视频流将转码为 H.264"
    fi
fi

# 检测音频编码格式
audio_codec_cmd=""
if [ -n "$audio_source" ]; then
    audio_codec=$(get_audio_codec "$audio_source" | tr '[:upper:]' '[:lower:]')
    echo "音频源编码格式: ${audio_codec:-未知}"
    
    if [[ "$audio_codec" == "aac" ]]; then
        audio_codec_cmd="-c:a copy"
        echo "  -> AAC 音频流将直接复制"
    else
        audio_codec_cmd="-c:a aac -b:a 128k"
        echo "  -> 非 AAC 音频流将转码为 AAC"
    fi
fi

# --- 步骤 3: 生成输出文件名 ---

output_dir=$(dirname "$1")
base_name=$(basename -- "$1")
name_without_ext="${base_name%.*}"
output_file="${output_dir}/${name_without_ext}_merge.mp4"

if [ -f "$output_file" ]; then
    echo "警告: ${output_file} 已存在。正在覆盖。"
fi

echo ""
echo "-> 正在合并文件并输出最终 MP4..."

# --- 步骤 4: 执行合并 ---

# 构建 ffmpeg 命令
FFMPEG_CMD="ffmpeg -y"

# 添加输入文件
if [ -n "$video_source" ]; then
    FFMPEG_CMD+=" -i \"$(realpath "$video_source")\""
fi

if [ -n "$audio_source" ]; then
    FFMPEG_CMD+=" -i \"$(realpath "$audio_source")\""
fi

# 添加映射和编码参数
if [ -n "$video_source" ] && [ -n "$audio_source" ]; then
    # 有视频和音频源
    FFMPEG_CMD+=" -map 0:v -map 1:a $video_codec_cmd $audio_codec_cmd -shortest"
    echo "合并视频源和音频源..."
elif [ -n "$video_source" ]; then
    # 只有视频源
    FFMPEG_CMD+=" -map 0:v $video_codec_cmd"
    echo "处理视频源..."
elif [ -n "$audio_source" ]; then
    # 只有音频源
    FFMPEG_CMD+=" -map 0:a $audio_codec_cmd"
    echo "处理音频源..."
fi

# 添加输出参数
FFMPEG_CMD+=" -movflags +faststart \"$output_file\""

echo "执行命令: $FFMPEG_CMD"
echo ""

# 执行合并
if eval "$FFMPEG_CMD"; then
    echo ""
    echo "✅ 成功合并文件，输出到: $output_file"
else
    echo "❌ 合并失败。请检查 ffmpeg 输出信息。"
    read -p "按任意键退出..."
    exit 1
fi

echo "合并处理完成。"
