#!/bin/bash

# Check if ffmpeg is installed
if ! command -v ffmpeg >/dev/null 2>&1; then
    echo "Error: ffmpeg command not found. Please install ffmpeg (e.g., sudo apt install ffmpeg)."
    exit 1
fi

# Check if at least two files are provided
if [ $# -lt 2 ]; then
    echo "Error: At least two MP4 files are required to merge."
    exit 1
fi

echo "Starting merge of selected MP4 videos..."

# Create a temporary file for the list
list_file=$(mktemp)

# Write each file to the list with absolute paths for safety
for i in "$@"; do
    if [ -f "$i" ] && [[ "$i" == *.mp4 ]]; then
        abs_i=$(realpath "$i")
        printf "file '%s'\n" "$abs_i" >> "$list_file"
    else
        echo "Skipping invalid file: $i"
    fi
done

# Determine output directory (use parent of first file)
first_file="$1"
output_dir=$(dirname "$(realpath "$first_file")")
output_file="${output_dir}/merged_video.mp4"

# Check if output file already exists
if [ -f "$output_file" ]; then
    echo "Warning: ${output_file} already exists. Overwriting."
fi

# Merge videos
if ffmpeg -f concat -safe 0 -i "$list_file" -c copy "$output_file"; then
    echo "Successfully merged videos to: $output_file"
else
    echo "Failed to merge videos."
fi

# Clean up
rm "$list_file"

echo "Merge process completed."
