#!/bin/bash

# Rofi 选项列表
options="锁定\n注销\n关机\n重启"

# *** 【关键更新点】 *** 使用 $HOME 变量
ROFI_CONFIG="$HOME/.dotfiles/rofi/rofi.rasi"

# 使用 Rofi 显示选单，并捕获用户的选择
chosen=$(echo -e "$options" | rofi -dmenu \
    -p "电源管理" \
    -config "$ROFI_CONFIG" \
    -selected-row 0)

# ... (Cinnamon 命令部分保持不变)
case "$chosen" in
    "锁定")
        cinnamon-screensaver-command --lock
        ;;
    "注销")
        cinnamon-session-quit --logout
        ;;
    "关机")
        systemctl poweroff
        ;;
    "重启")
        systemctl reboot
        ;;     
    *)
        exit 0
        ;;
esac